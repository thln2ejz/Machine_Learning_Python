'''
pricing optimization
@J.A.
'''

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#explore the data
path_to_file = './data/wtp.txt'
data = pd.read_csv(path_to_file)
data.head()
data.shape

data['wtp'].count()
data.describe()

#fit a normal distribution
plt.hist(data['wtp'], bins=8, density=True)
plt.xlabel('wtp')
plt.ylabel("density")
plt.grid()
plt.show()

#method of moments
from scipy import stats

mean = data['wtp'].mean()
std = data['wtp'].std()
x = np.linspace(data['wtp'].min(), data['wtp'].max(), 100)
y = stats.norm.pdf(x=x, loc=mean, scale=std)

#alternatively:
#distfit_norm = stats.norm(loc=mean, scale=std)
#plt.plot(x, distfit_norm.pdf(x))

plt.hist(data['wtp'], density=True)
plt.plot(x, y, lw=2, label='theoretical')
plt.xlabel('wtp')
plt.ylabel('density')
plt.title('Normal distribution of wtp by method of moments')
plt.grid()
plt.legend()
plt.show()

#method of maximum-likelihood
mean, std = stats.distributions.norm.fit(data['wtp'])
y = stats.norm.pdf(x, mean, std)

plt.hist(data['wtp'], density=True)
plt.plot(x, y, lw=2, label='theoretical')
plt.xlabel('wtp')
plt.ylabel('density')
plt.title('Normal distribution of wtp by method of maximum-likelihood')
plt.grid()
plt.legend()
plt.show()

data['wtp'].std() * np.sqrt((data['wtp'].count() - 1)/(data['wtp'].count())) #same as 'std' by maximum-likelihood

#fit a logistic distribution
#method of moments
loc = data['wtp'].mean()
scale = np.sqrt(data['wtp'].var() * 3 / np.pi**2)
x = np.linspace(data['wtp'].min(), data['wtp'].max(), 100)
y = stats.logistic.pdf(x=x, loc=loc, scale=scale)

plt.hist(data['wtp'], density=True)
plt.plot(x, y, lw=2, label='theoretical')
plt.xlabel('wtp')
plt.ylabel('density')
plt.title('Logistic distribution of wtp by method of moments')
plt.grid()
plt.legend()
plt.show()

#method of maximum-likelihood
loc, scale = stats.distributions.logistic.fit(data['wtp'])
y = stats.logistic.pdf(x, loc, scale)

plt.hist(data['wtp'], density=True)
plt.plot(x, y, lw=2, label='theoretical')
plt.xlabel('wtp')
plt.ylabel('density')
plt.title('Logistic distribution of wtp by method of maximum-likelihood')
plt.grid()
plt.legend()
plt.show()

#demand curve estimation
def demand(price,loc,scale,market_size):
    return market_size*(1-stats.logistic.cdf(price, loc=loc, scale=scale))

loc, scale = stats.distributions.logistic.fit(data['wtp'])
demand_values = demand(x, loc, scale, 10000)

plt.xlabel('price')
plt.ylabel('demand')
plt.title('Demand as a function of price')
plt.plot(x, demand_values, lw=2)
plt.show()

#price optimization
def profit(price, cost, loc, scale, market_size):
    return (price - cost)*demand(price, loc, scale, market_size) 

print(profit(30,15,loc,scale,10000))
print(profit(20,15,loc,scale,10000))
print(profit(18,15,loc,scale,10000))

def neg_profit(price, cost, loc, scale, market_size):
    return -1*profit(price, cost, loc, scale, market_size)

from scipy.optimize import minimize

optimized = minimize(fun=neg_profit, x0=20, args=(15, loc, scale, 10000), method='BFGS')

#alternatively:
optimized = minimize(lambda x : -profit(x, 15, loc, scale, 10000), x0=20, method='BFGS')

price_opt = optimized.x  #optimal price
profit_opt = -1*optimized.fun  #or profit(optimized.x, 15, loc, scale, 10000)[0] 

profit_values = profit(x, 15, loc,scale, 10000)

plt.plot(x, profit_values, lw=2)
plt.axhline(y=profit_opt, c='r', linestyle='--')
plt.axvline(x=price_opt, c='r', linestyle='--')
plt.xlabel('price')
plt.ylabel('profit')
plt.show()
