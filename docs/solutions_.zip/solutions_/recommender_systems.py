'''
recommender systems
@J.A.
'''

#read-in data
import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt

path_to_file = './data/invoices.csv'
data = pd.read_csv(path_to_file)
data.head()
data.shape

#data preparation
data.loc[data['quantity']<0].head(6) 
df = data.loc[data['quantity']>0]
df.loc[df['customer_id'].isna()]
df['customer_id'].isna().sum() 
df = df.dropna(subset=['customer_id'])  #or df.loc[~df['customer_id'].isna()]
df.shape

#customer-item matrix
#using: pivot_table()
user_item_matrix = pd.pivot_table(df, index='customer_id', columns='stock_code', values='quantity', aggfunc='sum', fill_value=0)
user_item_matrix.shape

df['stock_code'].nunique()
df['customer_id'].nunique()

user_item_matrix = user_item_matrix.applymap(lambda x: 1 if x > 0 else 0)

#alternatively: 
'''
stock_codes = df['stock_code'].unique()
customer_ids = df['customer_id'].unique()

stock_codes = np.sort(stock_codes)
customer_ids = np.sort(customer_ids)

user_item_matrix = pd.DataFrame(0,columns=stock_codes,index=customer_ids)

df_items = df.groupby('customer_id').aggregate({'stock_code': 'unique'})

for idx,customer in enumerate(df_items.index):
    user_item_matrix.loc[customer][df_items.loc[customer]['stock_code']] = 1
'''
    
user_item_matrix.head(6)

#collaborative filtering
#user-based collaborative filtering
from sklearn.metrics.pairwise import cosine_similarity

user_user_matrix = pd.DataFrame(cosine_similarity(user_item_matrix), columns=user_item_matrix.index, index=user_item_matrix.index)

#alternatively:
#user_user_matrix = cosine_similarity(user_item_matrix)
#user_user_matrix = pd.DataFrame(user_user_matrix, index=customer_ids, columns=customer_ids)

user_user_matrix.head()

#making recommendations
customer_id = 13645
neighbors = user_user_matrix.loc[customer_id].sort_values(ascending=False).index[1:10+1]
neighbors = neighbors.tolist() #or .values to obtain an array instead

ind = np.where(user_item_matrix.loc[customer_id,:]==1)
items_bought_by_customer = user_item_matrix.columns[ind].tolist()

#or 
items_bought_by_customer = df_items.loc[customer_id]['stock_code'].tolist()
 
ind = user_item_matrix.loc[neighbors].any(axis=0)
items_bought_by_neighbors = user_item_matrix.columns[ind].tolist()

items_to_recommend = list(set(items_bought_by_neighbors) - set(items_bought_by_customer)) #subtract sets

#alternatively
items_to_recommend = [x for x in items_bought_by_neighbors if x not in items_bought_by_customer]

items_to_recommend_descriptions = df.loc[df['stock_code'].isin(items_to_recommend), ['stock_code','description']].drop_duplicates().set_index('stock_code')

items_to_recommend_descriptions.sort_values(by=['stock_code'], ascending = True) 

#item-based collaborative filtering
item_item_matrix = pd.DataFrame(cosine_similarity(user_item_matrix.T), columns=user_item_matrix.columns, index=user_item_matrix.columns)
item_item_matrix.head()

stock_id = '71053'
similar_items = item_item_matrix[stock_id].sort_values(ascending=False).index[0:10+1] #keep the 0th

items_to_recommend_descriptions = df.loc[df['stock_code'].isin(similar_items), ['stock_code','description']].drop_duplicates().set_index('stock_code')
items_to_recommend_descriptions.sort_values(by=['stock_code'], ascending = True) 
