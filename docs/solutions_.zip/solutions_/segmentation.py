'''
segmentation
@J.A.
'''

#read-in data
import pandas as pd
import numpy as np 

path_to_file = './data/invoices.csv'
data = pd.read_csv(path_to_file)
data.head()
data.shape

#data preparation
data.loc[data['quantity']<0].head(6) 
df = data.loc[data['quantity']>0]
df.loc[df['customer_id'].isna()]
df = df.dropna(subset=['customer_id']) 
df.shape

df['invoice_date'] = pd.to_datetime(df['invoice_date'])
df['invoice_date'].min()
df['invoice_date'].max()

df = df.loc[df['invoice_date']<'2011-12-01']
df.shape 

df['quantity'].value_counts() #table count

#feature extraction
df['sales'] = df['quantity'] * df['unit_price']

df_customers = df.groupby(['customer_id']).aggregate({'sales': 'sum', 'invoice_date': 'nunique'})
df_customers = df_customers.rename(columns={'sales':'total_sales', 'invoice_date':'order_count'})
df_customers['avg_sales'] = df_customers['total_sales']/df_customers['order_count']

#alternatively:
df_customers['total_sales'] = df.groupby(['customer_id'])['sales'].sum() 
df_customers['order_count'] = df.groupby(['customer_id'])['invoice_date'].apply(lambda x: len(x.unique()))
df_customers['avg_sales'] = df_customers['total_sales']/df_customers['order_count']

df_customers.describe()
df_customers.shape

df_rank = df_customers.rank(method='first') #default is 'average'

from sklearn.preprocessing import scale

df_norm = pd.DataFrame(scale(df_rank), index=df_rank.index, columns=df_rank.columns) 

#alternatively: 
df_norm = (df_rank - df_rank.mean())/df_rank.std() #note: ddof for std is different between numpy and pandas

df_norm.describe().loc[['mean','std']] 

#customer segmentation by k-means clustering
from sklearn.cluster import KMeans
model = KMeans(n_clusters=4, max_iter=100, n_init=10).fit(df_norm)
model.labels_
model.cluster_centers_ #each row is a centroid

values, counts = np.unique(model.labels_, return_counts=True)
dict(zip(values, counts))

#or 
np.array(np.unique(model.labels_, return_counts=True))

#alternatively:
df_customers['label'] = model.labels_
df_customers.groupby(['label'])['order_count'].count()
     
#alternatively:
from collections import Counter
f'{Counter(model.labels_)}'

df_customers['label'] = model.labels_
df_customers.groupby(['label']).mean()

#optimal number of clusters by silhouette
from sklearn.metrics import silhouette_score

#store nothing
k_optimal, highest_score = 0, 0
for k in range(4,11):
    labels = KMeans(n_clusters=k, max_iter = 100, n_init=10).fit_predict(df_norm)
    score = silhouette_score(df_norm, labels)
    print(f'For k={k}, silhouette coefficient = {score}')

    if highest_score < score:
        highest_score = score
        k_optimal = k

k_optimal

#alternatively:
k_values, scores = range(4,11), []
for k in k_values:
    model = KMeans(n_clusters=k, max_iter = 100, n_init=10).fit(df_norm)
    score = silhouette_score(df_norm, model.labels_)
    scores.append(score)    

k_optimal = k_values[np.argmax(scores)]
k_optimal

model = KMeans(n_clusters=k_optimal, max_iter = 100, n_init=10).fit(df_norm)

df_customers['label'] = model.labels_ #overwrite labels with those of final model

table = df_customers.groupby('label').mean()
high_value_cluster = table['avg_sales'].idxmax()

#or
high_value_label = df_customers.groupby('label').mean()['avg_sales'].argmax() 

df_norm['label'] = model.labels_

#identify high-valued segment
high_valued_customers = df_customers.loc[df_customers['label'] == high_value_label]
high_valued_customers.describe()

#alternatively: .query('')
df_customers.query('label == @high_value_label').describe() 

vip = np.array(high_valued_customers.index) #.tolist()

#alternatively:
vip = df_customers.query('labels == @high_value_label').index.tolist()

df_vip = df.loc[df['customer_id'].isin(vip)]

items = df_vip.groupby('description').aggregate({'description': 'count'})
items = items.rename(columns= {'description': 'count'})

items = items.sort_values(by=["count"], ascending = False)
items.head(6)

#Note: if description index is required as column: 
items.reset_index() 

#alternatively:
items = df_vip.groupby('description').aggregate({'description': 'count'})
items = pd.DataFrame({'description':items.index.tolist(),'count':items.description.tolist()}) 
